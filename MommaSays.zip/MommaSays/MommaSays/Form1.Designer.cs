﻿namespace MommaSays
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mommaPictureBox = new System.Windows.Forms.PictureBox();
            this.greenBtn = new System.Windows.Forms.PictureBox();
            this.redBtn = new System.Windows.Forms.PictureBox();
            this.purpleBtn = new System.Windows.Forms.PictureBox();
            this.blueBtn = new System.Windows.Forms.PictureBox();
            this.pauseTimer = new System.Windows.Forms.Timer(this.components);
            this.scorePrompt = new System.Windows.Forms.Label();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.startBtn = new System.Windows.Forms.Button();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.mommaPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.redBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purpleBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueBtn)).BeginInit();
            this.SuspendLayout();
            // 
            // mommaPictureBox
            // 
            this.mommaPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mommaPictureBox.Image = global::MommaSays.Properties.Resources.allDull;
            this.mommaPictureBox.Location = new System.Drawing.Point(247, 120);
            this.mommaPictureBox.Name = "mommaPictureBox";
            this.mommaPictureBox.Size = new System.Drawing.Size(450, 330);
            this.mommaPictureBox.TabIndex = 0;
            this.mommaPictureBox.TabStop = false;
            // 
            // greenBtn
            // 
            this.greenBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.greenBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.greenBtn.Image = global::MommaSays.Properties.Resources.green;
            this.greenBtn.Location = new System.Drawing.Point(247, 497);
            this.greenBtn.Name = "greenBtn";
            this.greenBtn.Size = new System.Drawing.Size(100, 50);
            this.greenBtn.TabIndex = 1;
            this.greenBtn.TabStop = false;
            // 
            // redBtn
            // 
            this.redBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.redBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.redBtn.Image = global::MommaSays.Properties.Resources.red;
            this.redBtn.Location = new System.Drawing.Point(364, 497);
            this.redBtn.Name = "redBtn";
            this.redBtn.Size = new System.Drawing.Size(100, 50);
            this.redBtn.TabIndex = 2;
            this.redBtn.TabStop = false;
            // 
            // purpleBtn
            // 
            this.purpleBtn.BackgroundImage = global::MommaSays.Properties.Resources.purple;
            this.purpleBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.purpleBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.purpleBtn.Location = new System.Drawing.Point(485, 497);
            this.purpleBtn.Name = "purpleBtn";
            this.purpleBtn.Size = new System.Drawing.Size(100, 50);
            this.purpleBtn.TabIndex = 3;
            this.purpleBtn.TabStop = false;
            // 
            // blueBtn
            // 
            this.blueBtn.BackgroundImage = global::MommaSays.Properties.Resources.blue;
            this.blueBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.blueBtn.Location = new System.Drawing.Point(606, 497);
            this.blueBtn.Name = "blueBtn";
            this.blueBtn.Size = new System.Drawing.Size(100, 50);
            this.blueBtn.TabIndex = 4;
            this.blueBtn.TabStop = false;
            // 
            // pauseTimer
            // 
            this.pauseTimer.Interval = 1000;
            // 
            // scorePrompt
            // 
            this.scorePrompt.AutoSize = true;
            this.scorePrompt.Location = new System.Drawing.Point(12, 153);
            this.scorePrompt.Name = "scorePrompt";
            this.scorePrompt.Size = new System.Drawing.Size(55, 20);
            this.scorePrompt.TabIndex = 5;
            this.scorePrompt.Text = "Score:";
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Location = new System.Drawing.Point(85, 153);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(18, 20);
            this.scoreLabel.TabIndex = 6;
            this.scoreLabel.Text = "0";
            // 
            // startBtn
            // 
            this.startBtn.Location = new System.Drawing.Point(746, 120);
            this.startBtn.Name = "startBtn";
            this.startBtn.Size = new System.Drawing.Size(154, 111);
            this.startBtn.TabIndex = 7;
            this.startBtn.Text = "START";
            this.startBtn.UseVisualStyleBackColor = true;
            this.startBtn.Click += new System.EventHandler(this.startBtn_Click);
            // 
            // instructionLabel
            // 
            this.instructionLabel.BackColor = System.Drawing.Color.LightGray;
            this.instructionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.instructionLabel.Location = new System.Drawing.Point(12, 200);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(200, 250);
            this.instructionLabel.TabIndex = 8;
            this.instructionLabel.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(269, 550);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(387, 550);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(507, 550);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(629, 550);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "label5";
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(960, 650);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.startBtn);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.scorePrompt);
            this.Controls.Add(this.blueBtn);
            this.Controls.Add(this.purpleBtn);
            this.Controls.Add(this.redBtn);
            this.Controls.Add(this.greenBtn);
            this.Controls.Add(this.mommaPictureBox);
            this.Name = "mainForm";
            this.Text = "The UnHoly Cursive Eye Of Moma LeHarty";
            ((System.ComponentModel.ISupportInitialize)(this.mommaPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.redBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purpleBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueBtn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox mommaPictureBox;
        private System.Windows.Forms.PictureBox greenBtn;
        private System.Windows.Forms.PictureBox redBtn;
        private System.Windows.Forms.PictureBox purpleBtn;
        private System.Windows.Forms.PictureBox blueBtn;
        private System.Windows.Forms.Timer pauseTimer;
        private System.Windows.Forms.Label scorePrompt;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.Button startBtn;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

