﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MommaSays
{
    class Says
    {
        //Logic Original is the original idea for the computers logical skill. May be used for various reasons
        public static void logicOriginal(int level)
        {

            int challenge = 0;
            int counter;
            int tabs = 4;
            Random rand = new Random();
            List<int> memory = new List<int>();


            for (counter = 1; counter <= level; counter++)
            {
                challenge = rand.Next(tabs) + 1;
                memory.Add(challenge);
                foreach (int a in memory)
                {
                    Console.Write(a.ToString());
                }
                Console.WriteLine("");
            }
        }


        //Mommas mind determines the patterns to remember and writes them to a list
        public static List<int> mind()
        {
            int challenge = 0;
            int counter;
            int tabs = 4;
            Random rand = new Random();
            List<int> memory = new List<int>();


            for (counter = 1; counter <= 10; counter++)
            {
                challenge = rand.Next(tabs) + 1;
                memory.Add(challenge);
            }

            return memory;
        }

        public static void mommasTurn(List<int> herList, int round)
        {

        }


        public static void waitScreen(bool state, int starterCounter, PictureBox displayBox, Image imageLocation)
        {
            if (state == true)
            {


                switch (starterCounter)
                {

                    case 0:
                        {
                            displayBox.Image = imageLocation;
                            break;
                        }
                    case 1:
                        {
                            displayBox.Image = imageLocation;
                            break;
                        }
                    case 2:
                        {
                            displayBox.Image = imageLocation;
                            break;
                        }
                    case 3:
                        {
                            displayBox.Image = imageLocation;
                            break;
                        }
                }

            }
        }
        //For displaying the eye image in gameplay
        public static void showEye(int patternNumber, PictureBox displayBox, Image imageLocation)
        {


            switch (patternNumber)
            {

                case 1:
                    {
                        displayBox.Image = imageLocation;
                        break;
                    }
                case 2:
                    {
                        displayBox.Image = imageLocation;
                        break;
                    }
                case 3:
                    {
                        displayBox.Image = imageLocation;
                        break;
                    }
                case 4:
                    {
                        displayBox.Image = imageLocation;
                        break;
                    }
            }

        }


        public static void instructions(Label instructionPrompt)
        {
            string instruct;

            instruct = "MOMMA IS THE BOSS!!!!\n" +
            "MOMMA LEHARTY is a very demanding and stern momma. Follow her commands" +
            " by pressing the corresponding number to the color of the command she shows you or" +
            "clicking the correct color. If you forget all the commands....she will forgive you...." +
            "BUT ONLY 3 TIMES. After that, you lose the game. Simple huh???? Yea, we'll see." +
            "Better listen to what Momma says ya hear?";

            instructionPrompt.Text = instruct;
        }


        /*Tells Momma how many commands you can remember
        public static int yourIQ(int level)
        {
            switch (level)
            {
                case 1:
                    {
                        level = 10;
                        return level;
                    }
                case 2:
                    {
                        level = 20;
                        return level;
                    }
                case 3:
                    {
                        level = 30;
                        return level;
                    }
                case 4:
                    {
                        level = 40;
                        return level;
                    }
                default:
                    {
                        level = 60;
                        return level;
                    }
            }

        }
        */
    }
    
    
}