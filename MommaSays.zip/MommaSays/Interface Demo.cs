﻿/*
 * MOMMA SAYS
 * Momma Says is basically a version of the old 70's memory game. This one 
 * is very basic at the moment(8-21-17) but has potential. 
 */

 /*
  * THINGS TO ADD:
  * -Sound
  * -
  */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MommaSays;

namespace MommaSays
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }

        bool startUp = true;
        bool  yourTurn;
        int startUpCounter, eyeNumber, holder = 0, score = 0;
        int mommaCurrentPosition = 0, round = 0;
        
        //List of eye color images
        List<Image> eyes = new List<Image>();
        //List to hold the randomized pattern
        List<int> fullPattern = new List<int>();

        //Loading event that tells app what to do when it is loaded
        private void mainForm_Load(object sender, EventArgs e)
        {
            //Add the images to the Image list
            eyes.Add(MommaSays.Properties.Resources.purpleLight);
            eyes.Add(MommaSays.Properties.Resources.greenLight);
            eyes.Add(MommaSays.Properties.Resources.redLight);
            eyes.Add(MommaSays.Properties.Resources.blueLight);
            //Call the timer to start
            if (startUp == true)
            {
                initialTimer.Start();
            }

        }

        //Event for when the start button is clicked
        private void startBtn_Click(object sender, EventArgs e)
        {
            startUp = false;
            scoreLabel.Visible = true;
            scorePrompt.Visible = true;
            instructionLabel.Visible = true;
            Says.instructions(instructionLabel);
            startBtn.Visible = false;
            //Shows a lit-less eye to signify the beginning of the game;
            mommaPictureBox.Image = MommaSays.Properties.Resources.allDull;

            /*Full Pattern: Copies the random generated list(10 ints 1 -4) from Momma Class
             * and writes them to this class so we can use them
            */
            fullPattern = Says.mind();
            secondTimer.Start();


        }

        //Purple Button
        private void purpleBtn_Click(object sender, EventArgs e)
        {
            
            if (yourTurn == true)
            {
                showPositionColor(eyes, 1);
                holder = 1;
                if (holder == fullPattern[mommaCurrentPosition])
                {
                    score++;
                    scoreLabel.Text = score.ToString();
                    mommaCurrentPosition++;

                }
                if (mommaCurrentPosition == round + 1 && score > 0)
                {
                    yourTurn = false;
                    round++;
                    mommaCurrentPosition = 0;
                    secondTimer.Start();
                }
                holder = 0;
            }

        }

        //Green Button
        private void greenBtn_Click(object sender, EventArgs e)
        {
            
            if (yourTurn == true)
            {
                showPositionColor(eyes, 2);
                holder = 2;
                if (holder == fullPattern[mommaCurrentPosition])
                {
                    score++;
                    scoreLabel.Text = score.ToString();
                    mommaCurrentPosition++;

                }
                if (mommaCurrentPosition == round + 1 && score > 0)
                {
                    yourTurn = false;
                    round++;
                    mommaCurrentPosition = 0;
                    secondTimer.Start();
                }
                holder = 0;
            }
            
        }

        //Red Button
        private void redBtn_Click(object sender, EventArgs e)
        {
            
            if (yourTurn == true)
            {
                showPositionColor(eyes, 3);
                holder = 3;
                if (holder == fullPattern[mommaCurrentPosition])
                {
                    score++;
                    scoreLabel.Text = score.ToString();
                    mommaCurrentPosition++;

                }
                if (mommaCurrentPosition == round + 1 && score > 0)
                {
                    yourTurn = false;
                    round++;
                    mommaCurrentPosition = 0;
                    secondTimer.Start();
                }
                holder = 0;
            }
            
        }
       
        //Blue Button
        private void blueBtn_Click(object sender, EventArgs e)
        {
            
            if (yourTurn == true)
            {
                showPositionColor(eyes, 4);
                holder = 4;
                if (holder == fullPattern[mommaCurrentPosition])
                {
                    score++;
                    scoreLabel.Text = score.ToString();
                    mommaCurrentPosition++;

                }
                if (mommaCurrentPosition == round + 1 && score > 0)
                {
                    yourTurn = false;
                    round++;
                    mommaCurrentPosition = 0;
                    secondTimer.Start();
                }
                holder = 0;
            }
        }


        //Key down events that allow you to use the numbers 1-4 on top row instead of clicking
        private void mainForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                //Purple Button(1)
                case Keys.D1:
                    {
                        purpleBtn_Click(null, null);
                        break;
                    }
                //Green Button(2)
                case Keys.D2:
                    {
                        greenBtn_Click(null,null);
                        break;
                    }
                //Red Button(3)
                case Keys.D3:
                    {
                        redBtn_Click(null, null);
                        break;
                    }
                //Blue Button(4)
                case Keys.D4:
                    {
                        blueBtn_Click(null,null);
                        break;
                    }
            }
        }


        //Pause Timer(100ths of a second)
        private void pausingTimer_Tick(object sender, EventArgs e)
        {
            mommaPictureBox.Image = MommaSays.Properties.Resources.allDull;
            pausingTimer.Stop();
        }

        //Timer for displaying eye colors(1 second)
        private void secondTimer_Tick(object sender, EventArgs e)
        {
           
            if (mommaCurrentPosition > round)
            {
                mommaCurrentPosition = 0;
                secondTimer.Stop();
                yourTurn = true;
            }
            else if (mommaCurrentPosition <= round)
            {
                
                showPositionColor(eyes, fullPattern[mommaCurrentPosition]);
                pausingTimer.Start();
                mommaCurrentPosition++;
            }
            
        }

        /*
          * The main loader animation. Would like to have this change up and do different patterns
          */
        private void initialTimer_Tick(object sender, EventArgs e)
        {

            if (startUp == true)
            {
                /*Says.Wait is from the MommaClass. It takes in a bool to know whether or
                 * not its at start up, an int to tell which number to start at, a 
                 * picturebox to know where to display the image, and an image to know
                 * what image to display
                 */
                Says.waitScreen(startUp, startUpCounter, mommaPictureBox, eyes[eyeNumber]);
                eyeNumber++;
                if (eyeNumber > 3)
                {
                    eyeNumber = 0;
                }
            }
            else
            {
                //Timer that is ran at startup for the animation
                initialTimer.Stop();
            }


        }

        /*
         * Method for showing the eye color from the Image list "eyes"
         */
        public void showPositionColor(List<Image>eyes, int position)
        {
            switch (position)
            {
                case 1:
                    {
                        mommaPictureBox.Image = eyes[0];
                        break;
                    }
                case 2:
                    {
                        mommaPictureBox.Image = eyes[1];
                        break;
                    }
                case 3:
                    {
                        mommaPictureBox.Image = eyes[2];
                        break;
                    }
                case 4:
                    {
                        mommaPictureBox.Image = eyes[3];
                        break;
                    }

            }
        }
        
    }
}
