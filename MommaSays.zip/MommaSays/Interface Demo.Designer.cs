﻿namespace MommaSays
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mommaPictureBox = new System.Windows.Forms.PictureBox();
            this.greenBtn = new System.Windows.Forms.PictureBox();
            this.redBtn = new System.Windows.Forms.PictureBox();
            this.purpleBtn = new System.Windows.Forms.PictureBox();
            this.blueBtn = new System.Windows.Forms.PictureBox();
            this.initialTimer = new System.Windows.Forms.Timer(this.components);
            this.scorePrompt = new System.Windows.Forms.Label();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.startBtn = new System.Windows.Forms.Button();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.greenLabel = new System.Windows.Forms.Label();
            this.redLabel = new System.Windows.Forms.Label();
            this.purpleLabel = new System.Windows.Forms.Label();
            this.blueLabel = new System.Windows.Forms.Label();
            this.missesLabel = new System.Windows.Forms.Label();
            this.firstMissPictureBox = new System.Windows.Forms.PictureBox();
            this.secondMissPictureBox = new System.Windows.Forms.PictureBox();
            this.thirdMissPictureBox = new System.Windows.Forms.PictureBox();
            this.secondTimer = new System.Windows.Forms.Timer(this.components);
            this.pausingTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.mommaPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.redBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purpleBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstMissPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondMissPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thirdMissPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // mommaPictureBox
            // 
            this.mommaPictureBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mommaPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.mommaPictureBox.Image = global::MommaSays.Properties.Resources.allDull;
            this.mommaPictureBox.Location = new System.Drawing.Point(218, 48);
            this.mommaPictureBox.Name = "mommaPictureBox";
            this.mommaPictureBox.Size = new System.Drawing.Size(600, 440);
            this.mommaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.mommaPictureBox.TabIndex = 0;
            this.mommaPictureBox.TabStop = false;
            // 
            // greenBtn
            // 
            this.greenBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.greenBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.greenBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.greenBtn.Image = global::MommaSays.Properties.Resources.green;
            this.greenBtn.Location = new System.Drawing.Point(432, 494);
            this.greenBtn.Name = "greenBtn";
            this.greenBtn.Size = new System.Drawing.Size(100, 50);
            this.greenBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.greenBtn.TabIndex = 1;
            this.greenBtn.TabStop = false;
            this.greenBtn.Click += new System.EventHandler(this.greenBtn_Click);
            // 
            // redBtn
            // 
            this.redBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.redBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.redBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.redBtn.Image = global::MommaSays.Properties.Resources.red;
            this.redBtn.Location = new System.Drawing.Point(554, 495);
            this.redBtn.Name = "redBtn";
            this.redBtn.Size = new System.Drawing.Size(100, 50);
            this.redBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.redBtn.TabIndex = 2;
            this.redBtn.TabStop = false;
            this.redBtn.Click += new System.EventHandler(this.redBtn_Click);
            // 
            // purpleBtn
            // 
            this.purpleBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.purpleBtn.BackgroundImage = global::MommaSays.Properties.Resources.purple;
            this.purpleBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.purpleBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.purpleBtn.Location = new System.Drawing.Point(309, 494);
            this.purpleBtn.Name = "purpleBtn";
            this.purpleBtn.Size = new System.Drawing.Size(100, 50);
            this.purpleBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.purpleBtn.TabIndex = 3;
            this.purpleBtn.TabStop = false;
            this.purpleBtn.Click += new System.EventHandler(this.purpleBtn_Click);
            // 
            // blueBtn
            // 
            this.blueBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.blueBtn.BackgroundImage = global::MommaSays.Properties.Resources.blue;
            this.blueBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.blueBtn.Location = new System.Drawing.Point(678, 494);
            this.blueBtn.Name = "blueBtn";
            this.blueBtn.Size = new System.Drawing.Size(100, 50);
            this.blueBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.blueBtn.TabIndex = 4;
            this.blueBtn.TabStop = false;
            this.blueBtn.Click += new System.EventHandler(this.blueBtn_Click);
            // 
            // initialTimer
            // 
            this.initialTimer.Interval = 500;
            this.initialTimer.Tick += new System.EventHandler(this.initialTimer_Tick);
            // 
            // scorePrompt
            // 
            this.scorePrompt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.scorePrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scorePrompt.Location = new System.Drawing.Point(8, 136);
            this.scorePrompt.Name = "scorePrompt";
            this.scorePrompt.Size = new System.Drawing.Size(129, 54);
            this.scorePrompt.TabIndex = 5;
            this.scorePrompt.Text = "Score:";
            this.scorePrompt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.scorePrompt.Visible = false;
            // 
            // scoreLabel
            // 
            this.scoreLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.scoreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLabel.Location = new System.Drawing.Point(135, 122);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(70, 70);
            this.scoreLabel.TabIndex = 6;
            this.scoreLabel.Text = "0";
            this.scoreLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.scoreLabel.Visible = false;
            // 
            // startBtn
            // 
            this.startBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.startBtn.Location = new System.Drawing.Point(825, 120);
            this.startBtn.Name = "startBtn";
            this.startBtn.Size = new System.Drawing.Size(154, 111);
            this.startBtn.TabIndex = 7;
            this.startBtn.Text = "START";
            this.startBtn.UseVisualStyleBackColor = true;
            this.startBtn.Click += new System.EventHandler(this.startBtn_Click);
            // 
            // instructionLabel
            // 
            this.instructionLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.instructionLabel.BackColor = System.Drawing.Color.LightGray;
            this.instructionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.instructionLabel.Location = new System.Drawing.Point(12, 200);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(200, 403);
            this.instructionLabel.TabIndex = 8;
            this.instructionLabel.Visible = false;
            // 
            // greenLabel
            // 
            this.greenLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.greenLabel.AutoSize = true;
            this.greenLabel.Location = new System.Drawing.Point(448, 555);
            this.greenLabel.Name = "greenLabel";
            this.greenLabel.Size = new System.Drawing.Size(71, 40);
            this.greenLabel.TabIndex = 9;
            this.greenLabel.Text = "GREEN \n    (2)";
            // 
            // redLabel
            // 
            this.redLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.redLabel.AutoSize = true;
            this.redLabel.Location = new System.Drawing.Point(579, 555);
            this.redLabel.Name = "redLabel";
            this.redLabel.Size = new System.Drawing.Size(48, 40);
            this.redLabel.TabIndex = 10;
            this.redLabel.Text = "RED \n  (3)";
            // 
            // purpleLabel
            // 
            this.purpleLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.purpleLabel.AutoSize = true;
            this.purpleLabel.Location = new System.Drawing.Point(318, 555);
            this.purpleLabel.Name = "purpleLabel";
            this.purpleLabel.Size = new System.Drawing.Size(77, 40);
            this.purpleLabel.TabIndex = 11;
            this.purpleLabel.Text = "PURPLE \n     (1)";
            // 
            // blueLabel
            // 
            this.blueLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.blueLabel.AutoSize = true;
            this.blueLabel.Location = new System.Drawing.Point(706, 551);
            this.blueLabel.Name = "blueLabel";
            this.blueLabel.Size = new System.Drawing.Size(56, 40);
            this.blueLabel.TabIndex = 12;
            this.blueLabel.Text = "BLUE \n   (4)";
            // 
            // missesLabel
            // 
            this.missesLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.missesLabel.AutoSize = true;
            this.missesLabel.Location = new System.Drawing.Point(930, 283);
            this.missesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.missesLabel.Name = "missesLabel";
            this.missesLabel.Size = new System.Drawing.Size(58, 20);
            this.missesLabel.TabIndex = 13;
            this.missesLabel.Text = "Misses";
            // 
            // firstMissPictureBox
            // 
            this.firstMissPictureBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.firstMissPictureBox.Location = new System.Drawing.Point(840, 329);
            this.firstMissPictureBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.firstMissPictureBox.Name = "firstMissPictureBox";
            this.firstMissPictureBox.Size = new System.Drawing.Size(75, 77);
            this.firstMissPictureBox.TabIndex = 14;
            this.firstMissPictureBox.TabStop = false;
            // 
            // secondMissPictureBox
            // 
            this.secondMissPictureBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.secondMissPictureBox.Location = new System.Drawing.Point(926, 329);
            this.secondMissPictureBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.secondMissPictureBox.Name = "secondMissPictureBox";
            this.secondMissPictureBox.Size = new System.Drawing.Size(75, 77);
            this.secondMissPictureBox.TabIndex = 15;
            this.secondMissPictureBox.TabStop = false;
            // 
            // thirdMissPictureBox
            // 
            this.thirdMissPictureBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.thirdMissPictureBox.Location = new System.Drawing.Point(1011, 329);
            this.thirdMissPictureBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.thirdMissPictureBox.Name = "thirdMissPictureBox";
            this.thirdMissPictureBox.Size = new System.Drawing.Size(75, 77);
            this.thirdMissPictureBox.TabIndex = 16;
            this.thirdMissPictureBox.TabStop = false;
            // 
            // secondTimer
            // 
            this.secondTimer.Interval = 1000;
            this.secondTimer.Tick += new System.EventHandler(this.secondTimer_Tick);
            // 
            // pausingTimer
            // 
            this.pausingTimer.Tick += new System.EventHandler(this.pausingTimer_Tick);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1102, 649);
            this.Controls.Add(this.thirdMissPictureBox);
            this.Controls.Add(this.secondMissPictureBox);
            this.Controls.Add(this.firstMissPictureBox);
            this.Controls.Add(this.missesLabel);
            this.Controls.Add(this.blueLabel);
            this.Controls.Add(this.purpleLabel);
            this.Controls.Add(this.redLabel);
            this.Controls.Add(this.greenLabel);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.startBtn);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.scorePrompt);
            this.Controls.Add(this.blueBtn);
            this.Controls.Add(this.purpleBtn);
            this.Controls.Add(this.redBtn);
            this.Controls.Add(this.greenBtn);
            this.Controls.Add(this.mommaPictureBox);
            this.KeyPreview = true;
            this.Name = "mainForm";
            this.Text = "The UnHoly Cursive Eye Of Momma LeHarty";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mainForm_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.mommaPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.redBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purpleBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstMissPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondMissPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thirdMissPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox mommaPictureBox;
        private System.Windows.Forms.PictureBox greenBtn;
        private System.Windows.Forms.PictureBox redBtn;
        private System.Windows.Forms.PictureBox purpleBtn;
        private System.Windows.Forms.PictureBox blueBtn;
        private System.Windows.Forms.Timer initialTimer;
        private System.Windows.Forms.Label scorePrompt;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.Button startBtn;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label greenLabel;
        private System.Windows.Forms.Label redLabel;
        private System.Windows.Forms.Label purpleLabel;
        private System.Windows.Forms.Label blueLabel;
        private System.Windows.Forms.Label missesLabel;
        private System.Windows.Forms.PictureBox firstMissPictureBox;
        private System.Windows.Forms.PictureBox secondMissPictureBox;
        private System.Windows.Forms.PictureBox thirdMissPictureBox;
        private System.Windows.Forms.Timer secondTimer;
        private System.Windows.Forms.Timer pausingTimer;
    }
}

